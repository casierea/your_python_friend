from CasieMayaTools import Renamer
from CasieMayaTools import RandomGenUi
#from CasieMayaTools import *

my_window = Renamer.RenamerUI() #remove from script when done
my_window.create()

my_window = RandomGenUi.RandomUI()  # remove from script when done
my_window.create()
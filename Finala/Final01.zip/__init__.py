#can add whatever you want to run when import it
#import markin gmenu
#import cbox
#reload(marking_menu)
#reload(cbox)

#cbox.ChannelBox().create()

#This is what Clayton has in his script to have the tools automatically load in scene
#anything you want to run, add it to this file.